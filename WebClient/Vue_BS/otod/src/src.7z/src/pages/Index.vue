<template>
    <span>HELLO world</span>
</template>

<script>
export default {
  name: 'Index',
  created: function () {

  }
}
</script>

<style>
    @import '../assets/css/indexPage.css';
</style>

