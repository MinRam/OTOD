<template>
    <div>
        <el-row>
            <el-col :span="12" :offset="4">
                <el-ul>
                    <el-li v-for="m in message" :key="m.id">
                        <el-row class="message-bottom" type="flex" justify="center">
                            <el-col :span="18">
                                <el-container class="bg-purple">
                                    <el-aside width="200px">Aside</el-aside>
                                    <el-container>
                                        <el-header>{{ m.title }}</el-header>
                                        <el-main>{{ m.content }}</el-main>
                                    </el-container>
                                </el-container>
                            </el-col>
                        </el-row>
                    </el-li>
                </el-ul>
            </el-col>
        </el-row>
    </div>
</template>

<script src="../utils/vue.js"></script>
<script>
export default {
    name: 'Index',
    data() {
        return {
            message: [{
                title: 'this is First title',
                content: 'Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !'
              }, {
                title: 'this is Second title',
                content: 'Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !'
              }, {
                title: 'this is Third title',
                content: 'Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !'
              }, {
                title: 'this is Forth title',
                content: 'Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !Content !'
              }]
        }
    }
}
</script>
<style>
    @import '../assets/css/servicePage.css';
</style>
